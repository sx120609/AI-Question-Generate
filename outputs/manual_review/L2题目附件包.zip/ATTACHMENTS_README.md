# 附件下载清单

生成日期：2026-07-09

说明：每条题目 6 个附件均已保存到本地目录。下载器支持 HTML、PDF、DOCX、XLSX、CSV、JSON、TXT、PNG/JPEG/GIF、ZIP 等常见附件；能下载原文件时保留原格式。

## 睡眠健康App上架前数据安全与素材合规预审 / 01 Apple App Store 审核指南

- 格式：HTML
- 本地文件：C:\Users\Carbene\Documents\GitHub\AI-Question-Generate\outputs\attachments\睡眠健康App上架前数据安全与素材合规预审\Apple_App_Store审核指南_应用安全隐私与法律要求.html
- 大小：234360 bytes
- 校验：PASS: keyword check OK
- 来源：https://developer.apple.com/app-store/review/guidelines/

## 睡眠健康App上架前数据安全与素材合规预审 / 02 Apple App Store 产品页创建说明

- 格式：HTML
- 本地文件：C:\Users\Carbene\Documents\GitHub\AI-Question-Generate\outputs\attachments\睡眠健康App上架前数据安全与素材合规预审\Apple_App_Store产品页元数据创建说明.html
- 大小：134864 bytes
- 校验：PASS: keyword check OK
- 来源：https://developer.apple.com/app-store/product-page/

## 睡眠健康App上架前数据安全与素材合规预审 / 03 Apple App 隐私详情与数据类型说明

- 格式：HTML
- 本地文件：C:\Users\Carbene\Documents\GitHub\AI-Question-Generate\outputs\attachments\睡眠健康App上架前数据安全与素材合规预审\Apple_App隐私详情与数据类型说明.html
- 大小：117295 bytes
- 校验：PASS: keyword check OK
- 来源：https://developer.apple.com/app-store/app-privacy-details/

## 睡眠健康App上架前数据安全与素材合规预审 / 04 Google Play 数据安全表单填写说明

- 格式：HTML
- 本地文件：C:\Users\Carbene\Documents\GitHub\AI-Question-Generate\outputs\attachments\睡眠健康App上架前数据安全与素材合规预审\Google_Play数据安全表单填写说明.html
- 大小：1488875 bytes
- 校验：PASS: keyword check OK
- 来源：https://support.google.com/googleplay/android-developer/answer/10787469?hl=en

## 睡眠健康App上架前数据安全与素材合规预审 / 05 Google Play 健康应用类别与声明要求

- 格式：HTML
- 本地文件：C:\Users\Carbene\Documents\GitHub\AI-Question-Generate\outputs\attachments\睡眠健康App上架前数据安全与素材合规预审\Google_Play健康应用类别与声明要求.html
- 大小：1416250 bytes
- 校验：PASS: keyword check OK
- 来源：https://support.google.com/googleplay/android-developer/answer/13996367?hl=en

## 睡眠健康App上架前数据安全与素材合规预审 / 06 FTC 背书与推荐广告指南（2023）

- 格式：PDF
- 本地文件：C:\Users\Carbene\Documents\GitHub\AI-Question-Generate\outputs\attachments\睡眠健康App上架前数据安全与素材合规预审\FTC_背书与推荐广告指南_2023.pdf
- 大小：725040 bytes
- 校验：PASS: PDF signature OK
- 来源：https://www.ftc.gov/system/files/ftc_gov/pdf/p204500_endorsement_guides_in_2023.pdf

## 科罗拉多酒店停车场EV充电桩选址与税务预审 / 01 AFDC 替代燃料站数据下载说明

- 格式：HTML
- 本地文件：C:\Users\Carbene\Documents\GitHub\AI-Question-Generate\outputs\attachments\科罗拉多酒店停车场EV充电桩选址与税务预审\AFDC_替代燃料站数据下载说明.html
- 大小：67028 bytes
- 校验：PASS: keyword check OK
- 来源：https://afdc.energy.gov/data_download

## 科罗拉多酒店停车场EV充电桩选址与税务预审 / 02 AFDC 替代燃料站 API 说明 All Stations

- 格式：HTML
- 本地文件：C:\Users\Carbene\Documents\GitHub\AI-Question-Generate\outputs\attachments\科罗拉多酒店停车场EV充电桩选址与税务预审\AFDC_替代燃料站API说明_All_Stations.html
- 大小：303055 bytes
- 校验：PASS: keyword check OK
- 来源：https://developer.nlr.gov/docs/transportation/alt-fuel-stations-v1/all/

## 科罗拉多酒店停车场EV充电桩选址与税务预审 / 03 AFDC 科罗拉多 EV 充电站数据

- 格式：CSV
- 本地文件：C:\Users\Carbene\Documents\GitHub\AI-Question-Generate\outputs\attachments\科罗拉多酒店停车场EV充电桩选址与税务预审\AFDC_科罗拉多EV充电站数据_2026-07-08.csv
- 大小：1053973 bytes
- 校验：PASS: CSV signature OK
- 来源：https://developer.nlr.gov/api/alt-fuel-stations/v1.csv?api_key=DEMO_KEY&fuel_type=ELEC&state=CO&limit=all

## 科罗拉多酒店停车场EV充电桩选址与税务预审 / 04 Joint Office 公共 EV 充电站选址检查清单

- 格式：PDF
- 本地文件：C:\Users\Carbene\Documents\GitHub\AI-Question-Generate\outputs\attachments\科罗拉多酒店停车场EV充电桩选址与税务预审\Joint_Office_公共EV充电站选址检查清单.pdf
- 大小：271375 bytes
- 校验：PASS: PDF signature OK
- 来源：https://driveelectric.gov/files/ev-site-selection.pdf

## 科罗拉多酒店停车场EV充电桩选址与税务预审 / 05 IRS Form 8911 说明

- 格式：PDF
- 本地文件：C:\Users\Carbene\Documents\GitHub\AI-Question-Generate\outputs\attachments\科罗拉多酒店停车场EV充电桩选址与税务预审\IRS_Form8911说明_替代燃料车辆加注设施抵免_2025版.pdf
- 大小：153260 bytes
- 校验：PASS: PDF signature OK
- 来源：https://www.irs.gov/pub/irs-pdf/i8911.pdf

## 科罗拉多酒店停车场EV充电桩选址与税务预审 / 06 IRS 企业替代燃料车辆加注设施抵免说明

- 格式：PDF
- 本地文件：C:\Users\Carbene\Documents\GitHub\AI-Question-Generate\outputs\attachments\科罗拉多酒店停车场EV充电桩选址与税务预审\IRS_企业替代燃料车辆加注设施抵免说明_2026-06.pdf
- 大小：295245 bytes
- 校验：PASS: PDF signature OK
- 来源：https://www.irs.gov/pub/irs-pdf/p6028.pdf
